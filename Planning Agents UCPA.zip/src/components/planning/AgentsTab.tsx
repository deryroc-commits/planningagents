import { useState } from "react";
import { ArrowDown, ArrowUp, CalendarCheck, CalendarX, GripVertical, LogIn, LogOut, Pencil, Plus, RotateCcw, Save, Trash2, X } from "lucide-react";
import { usePlanning } from "@/lib/planning/store";
import { hasAgentName } from "@/lib/planning/visible-agents";
import { MONTHS } from "@/lib/planning/calc";
import { useSelectableYears } from "@/hooks/use-selectable-years";
import type { Agent, AgentSortMode } from "@/lib/planning/types";
import { AGENT_SORT_LABELS } from "@/lib/planning/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

function arrivalLabel(a: Agent): string | null {
  if (a.startYear == null || a.startMonth == null) return null;
  return `${MONTHS[a.startMonth]} ${a.startYear}`;
}
function departureLabel(a: Agent): string | null {
  if (a.endYear == null || a.endMonth == null) return null;
  return `${MONTHS[a.endMonth]} ${a.endYear}`;
}

export function AgentsTab() {
  const { agents, addAgent, updateAgent, removeAgent, yearRange, agentSort, setAgentSort, moveAgent, reorderAgent, teamOrder, moveTeam, reorderTeam, resetTeamOrder } = usePlanning();
  const years = useSelectableYears(yearRange);
  const now = new Date();

  const [editing, setEditing] = useState<string | null>(null);
  const [draftName, setDraftName] = useState("");
  const [draftTeam, setDraftTeam] = useState("");
  const [draftArrEnabled, setDraftArrEnabled] = useState(false);
  const [draftArrMonth, setDraftArrMonth] = useState(0);
  const [draftArrYear, setDraftArrYear] = useState(new Date().getFullYear());
  const [draftDepEnabled, setDraftDepEnabled] = useState(false);
  const [draftDepMonth, setDraftDepMonth] = useState(0);
  const [draftDepYear, setDraftDepYear] = useState(new Date().getFullYear());

  // Drag & drop reordering.
  const [dragTeam, setDragTeam] = useState<string | null>(null);
  const [overTeam, setOverTeam] = useState<string | null>(null);
  const [dragAgent, setDragAgent] = useState<string | null>(null);
  const [overAgent, setOverAgent] = useState<string | null>(null);



  // Add form.
  const [newName, setNewName] = useState("");
  const [newTeam, setNewTeam] = useState("");
  const [arrEnabled, setArrEnabled] = useState(false);
  const [newArrMonth, setNewArrMonth] = useState(now.getMonth());
  const [newArrYear, setNewArrYear] = useState(now.getFullYear());

  // Departure / arrival / delete dialog state.
  const [dialogAgent, setDialogAgent] = useState<Agent | null>(null);
  const [depEnabled, setDepEnabled] = useState(false);
  const [depMonth, setDepMonth] = useState(now.getMonth());
  const [depYear, setDepYear] = useState(now.getFullYear());
  const [dArrEnabled, setDArrEnabled] = useState(false);
  const [dArrMonth, setDArrMonth] = useState(now.getMonth());
  const [dArrYear, setDArrYear] = useState(now.getFullYear());
  const [confirmDelete, setConfirmDelete] = useState(false);

  const startEdit = (id: string, a: Agent) => {
    setEditing(id);
    setDraftName(a.name);
    setDraftTeam(a.team ?? "");
    setDraftArrEnabled(a.startYear != null && a.startMonth != null);
    setDraftArrMonth(a.startMonth ?? now.getMonth());
    setDraftArrYear(a.startYear ?? now.getFullYear());
    setDraftDepEnabled(a.endYear != null && a.endMonth != null);
    setDraftDepMonth(a.endMonth ?? now.getMonth());
    setDraftDepYear(a.endYear ?? now.getFullYear());
  };
  const saveEdit = () => {
    if (!editing) return;
    if (draftName.trim())
      updateAgent(editing, {
        name: draftName.trim(),
        team: draftTeam.trim() || undefined,
        startYear: draftArrEnabled ? draftArrYear : undefined,
        startMonth: draftArrEnabled ? draftArrMonth : undefined,
        endYear: draftDepEnabled ? draftDepYear : undefined,
        endMonth: draftDepEnabled ? draftDepMonth : undefined,
      });
    setEditing(null);
  };
  const addNew = () => {
    if (!newName.trim()) return;
    addAgent({
      name: newName.trim(),
      team: newTeam.trim() || undefined,
      ...(arrEnabled ? { startYear: newArrYear, startMonth: newArrMonth } : {}),
    });
    setNewName("");
    setNewTeam("");
    setArrEnabled(false);
  };

  const openDialog = (a: Agent) => {
    setDialogAgent(a);
    setConfirmDelete(false);
    setDepEnabled(a.endYear != null && a.endMonth != null);
    setDepMonth(a.endMonth ?? now.getMonth());
    setDepYear(a.endYear ?? now.getFullYear());
    setDArrEnabled(a.startYear != null && a.startMonth != null);
    setDArrMonth(a.startMonth ?? now.getMonth());
    setDArrYear(a.startYear ?? now.getFullYear());
  };
  const closeDialog = () => {
    setDialogAgent(null);
    setConfirmDelete(false);
  };
  const saveDialog = () => {
    if (!dialogAgent) return;
    updateAgent(dialogAgent.id, {
      startYear: dArrEnabled ? dArrYear : undefined,
      startMonth: dArrEnabled ? dArrMonth : undefined,
      endYear: depEnabled ? depYear : undefined,
      endMonth: depEnabled ? depMonth : undefined,
    });
    closeDialog();
  };
  const deletePermanently = () => {
    if (!dialogAgent) return;
    removeAgent(dialogAgent.id);
    closeDialog();
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="text-lg font-semibold">Base agents</h2>
          <p className="text-sm text-muted-foreground">
            Liste des agents affichés dans le planning ({agents.filter(hasAgentName).length}).
          </p>
        </div>
        <div className="min-w-[220px]">
          <label className="mb-1 block text-xs font-medium text-muted-foreground">
            Classement des agents (tous les onglets)
          </label>
          <Select
            value={agentSort}
            onValueChange={(v) => setAgentSort(v as AgentSortMode)}
          >
            <SelectTrigger className="w-full">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {(Object.keys(AGENT_SORT_LABELS) as AgentSortMode[]).map((m) => (
                <SelectItem key={m} value={m}>
                  {AGENT_SORT_LABELS[m]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {(agentSort === "team" || agentSort === "team-alpha") && teamOrder.length > 0 && (
        <div className="space-y-2 rounded-lg border border-border bg-card p-3">
          <div className="flex items-start justify-between gap-3">
            <div>
              <h3 className="text-sm font-semibold">Ordre des équipes</h3>
              <p className="text-xs text-muted-foreground">
                Glissez-déposez les équipes (ou utilisez les flèches) pour définir leur ordre dans tous les onglets.
              </p>
            </div>
            <Button
              variant="outline"
              size="sm"
              className="h-8 gap-1 text-xs"
              onClick={resetTeamOrder}
            >
              <RotateCcw className="size-3.5" /> Réinitialiser
            </Button>
          </div>
          <ul className="divide-y divide-border rounded-md border border-border">
            {teamOrder.map((team, idx) => (
              <li
                key={team}
                draggable
                onDragStart={(e) => {
                  setDragTeam(team);
                  e.dataTransfer.effectAllowed = "move";
                }}
                onDragOver={(e) => {
                  e.preventDefault();
                  if (dragTeam && dragTeam !== team) setOverTeam(team);
                }}
                onDragLeave={() => setOverTeam((t) => (t === team ? null : t))}
                onDrop={(e) => {
                  e.preventDefault();
                  if (dragTeam && dragTeam !== team) reorderTeam(dragTeam, idx);
                  setDragTeam(null);
                  setOverTeam(null);
                }}
                onDragEnd={() => {
                  setDragTeam(null);
                  setOverTeam(null);
                }}
                className={`flex items-center justify-between gap-2 px-3 py-1.5 transition-colors ${
                  dragTeam === team ? "opacity-50" : ""
                } ${overTeam === team ? "bg-accent" : ""}`}
              >
                <span className="flex items-center gap-2 text-sm font-medium">
                  <GripVertical className="size-4 cursor-grab text-muted-foreground" />
                  {team}
                </span>
                <div className="flex gap-1">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="size-8"
                    title="Monter"
                    disabled={idx === 0}
                    onClick={() => moveTeam(team, "up")}
                  >
                    <ArrowUp />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="size-8"
                    title="Descendre"
                    disabled={idx === teamOrder.length - 1}
                    onClick={() => moveTeam(team, "down")}
                  >
                    <ArrowDown />
                  </Button>
                </div>
              </li>
            ))}
          </ul>
        </div>
      )}

      <div className="space-y-3 rounded-lg border border-border bg-card p-3">
        <div className="flex flex-wrap items-end gap-2">
          <div className="flex-1 min-w-[180px]">
            <label className="mb-1 block text-xs font-medium text-muted-foreground">
              Nom de l'agent
            </label>
            <Input
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && addNew()}
              placeholder="Nom Prénom"
            />
          </div>
          <div className="flex-1 min-w-[160px]">
            <label className="mb-1 block text-xs font-medium text-muted-foreground">
              Équipe (optionnel)
            </label>
            <Input
              value={newTeam}
              onChange={(e) => setNewTeam(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && addNew()}
              placeholder="Équipe A"
            />
          </div>
          <Button onClick={addNew}>
            <Plus /> Ajouter
          </Button>
        </div>

        <div className="flex flex-wrap items-center gap-3 rounded-md bg-muted/50 p-2">
          <label className="flex items-center gap-2 text-sm font-medium">
            <Checkbox
              checked={arrEnabled}
              onCheckedChange={(v) => setArrEnabled(v === true)}
            />
            Arrivée à partir d'un mois
          </label>
          {arrEnabled ? (
            <div className="flex flex-wrap items-center gap-2">
              <Select
                value={String(newArrMonth)}
                onValueChange={(v) => setNewArrMonth(Number(v))}
              >
                <SelectTrigger className="w-36">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {MONTHS.map((m, i) => (
                    <SelectItem key={m} value={String(i)}>
                      {m}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select
                value={String(newArrYear)}
                onValueChange={(v) => setNewArrYear(Number(v))}
              >
                <SelectTrigger className="w-28">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {years.map((y) => (
                    <SelectItem key={y} value={String(y)}>
                      {y}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          ) : (
            <span className="text-sm text-muted-foreground">
              Présent tout de suite (tous les mois).
            </span>
          )}
        </div>
      </div>

      <div className="overflow-x-auto overscroll-x-contain touch-pan-x rounded-lg border border-border bg-card [-webkit-overflow-scrolling:touch]">
        <table className="w-full min-w-[720px] text-sm">
          <thead>
            <tr className="border-b border-border bg-muted text-left">
              <th className="sticky left-0 z-20 bg-muted px-3 py-2 font-medium">Nom</th>
              <th className="px-3 py-2 font-medium">Équipe</th>
              <th className="px-3 py-2 font-medium">Arrivée</th>
              <th className="px-3 py-2 font-medium">Départ</th>
              <th className="px-3 py-2 text-right font-medium">Actions</th>
            </tr>
          </thead>
          <tbody>
            {agents.filter(hasAgentName).map((a, idx) => {
              const arr = arrivalLabel(a);
              const dep = departureLabel(a);
              return (
                <tr
                  key={a.id}
                  draggable={agentSort === "custom" && editing !== a.id}
                  onDragStart={(e) => {
                    if (agentSort !== "custom") return;
                    setDragAgent(a.id);
                    e.dataTransfer.effectAllowed = "move";
                  }}
                  onDragOver={(e) => {
                    if (agentSort !== "custom" || !dragAgent) return;
                    e.preventDefault();
                    if (dragAgent !== a.id) setOverAgent(a.id);
                  }}
                  onDragLeave={() => setOverAgent((x) => (x === a.id ? null : x))}
                  onDrop={(e) => {
                    if (agentSort !== "custom") return;
                    e.preventDefault();
                    if (dragAgent && dragAgent !== a.id) reorderAgent(dragAgent, idx);
                    setDragAgent(null);
                    setOverAgent(null);
                  }}
                  onDragEnd={() => {
                    setDragAgent(null);
                    setOverAgent(null);
                  }}
                  className={`border-b border-border last:border-0 transition-colors ${
                    dragAgent === a.id ? "opacity-50" : ""
                  } ${overAgent === a.id ? "bg-accent" : ""}`}
                >
                  {editing === a.id ? (
                    <>
                      <td className="sticky left-0 z-10 bg-card px-3 py-2">
                        <Input
                          value={draftName}
                          onChange={(e) => setDraftName(e.target.value)}
                          className="h-8"
                        />
                      </td>
                      <td className="px-3 py-2">
                        <Input
                          value={draftTeam}
                          onChange={(e) => setDraftTeam(e.target.value)}
                          className="h-8"
                        />
                      </td>
                      <td className="px-3 py-2">
                        <div className="flex flex-col gap-1">
                          <label className="flex items-center gap-1.5 text-xs font-medium">
                            <Checkbox
                              checked={draftArrEnabled}
                              onCheckedChange={(v) => setDraftArrEnabled(v === true)}
                            />
                            Définir
                          </label>
                          {draftArrEnabled && (
                            <div className="flex gap-1">
                              <Select value={String(draftArrMonth)} onValueChange={(v) => setDraftArrMonth(Number(v))}>
                                <SelectTrigger className="h-8 w-28"><SelectValue /></SelectTrigger>
                                <SelectContent>
                                  {MONTHS.map((m, i) => (
                                    <SelectItem key={m} value={String(i)}>{m}</SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <Select value={String(draftArrYear)} onValueChange={(v) => setDraftArrYear(Number(v))}>
                                <SelectTrigger className="h-8 w-20"><SelectValue /></SelectTrigger>
                                <SelectContent>
                                  {years.map((y) => (
                                    <SelectItem key={y} value={String(y)}>{y}</SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            </div>
                          )}
                        </div>
                      </td>
                      <td className="px-3 py-2">
                        <div className="flex flex-col gap-1">
                          <label className="flex items-center gap-1.5 text-xs font-medium">
                            <Checkbox
                              checked={draftDepEnabled}
                              onCheckedChange={(v) => setDraftDepEnabled(v === true)}
                            />
                            Définir
                          </label>
                          {draftDepEnabled && (
                            <div className="flex gap-1">
                              <Select value={String(draftDepMonth)} onValueChange={(v) => setDraftDepMonth(Number(v))}>
                                <SelectTrigger className="h-8 w-28"><SelectValue /></SelectTrigger>
                                <SelectContent>
                                  {MONTHS.map((m, i) => (
                                    <SelectItem key={m} value={String(i)}>{m}</SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <Select value={String(draftDepYear)} onValueChange={(v) => setDraftDepYear(Number(v))}>
                                <SelectTrigger className="h-8 w-20"><SelectValue /></SelectTrigger>
                                <SelectContent>
                                  {years.map((y) => (
                                    <SelectItem key={y} value={String(y)}>{y}</SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            </div>
                          )}
                        </div>
                      </td>
                      <td className="px-3 py-2">
                        <div className="flex justify-end gap-1">
                          <Button
                            size="icon"
                            className="size-10 sm:size-8"
                            title="Enregistrer"
                            onClick={saveEdit}
                          >
                            <Save />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="size-10 sm:size-8"
                            title="Annuler"
                            onClick={() => setEditing(null)}
                          >
                            <X />
                          </Button>
                        </div>
                      </td>
                    </>
                  ) : (
                    <>
                      <td className="sticky left-0 z-10 bg-card px-3 py-2 font-medium">
                        <span className="flex items-center gap-2">
                          {agentSort === "custom" && (
                            <GripVertical className="size-4 cursor-grab text-muted-foreground" />
                          )}
                          {a.name}
                        </span>
                      </td>
                      <td className="px-3 py-2 text-muted-foreground">
                        {a.team ?? "—"}
                      </td>
                      <td className="px-3 py-2">
                        {arr ? (
                          <span className="inline-flex items-center gap-1 rounded bg-muted px-1.5 py-0.5 text-xs font-medium text-muted-foreground">
                            <CalendarCheck className="size-3.5" /> {arr}
                          </span>
                        ) : (
                          <span className="text-muted-foreground">—</span>
                        )}
                      </td>
                      <td className="px-3 py-2">
                        {dep ? (
                          <span className="inline-flex items-center gap-1 rounded bg-muted px-1.5 py-0.5 text-xs font-medium text-muted-foreground">
                            <CalendarX className="size-3.5" /> {dep}
                          </span>
                        ) : (
                          <span className="text-muted-foreground">—</span>
                        )}
                      </td>
                      <td className="px-3 py-2">

                        <div className="flex justify-end gap-1">
                          {agentSort === "custom" && (
                            <>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="size-10 sm:size-8"
                                title="Monter"
                                disabled={idx === 0}
                                onClick={() => moveAgent(a.id, "up")}
                              >
                                <ArrowUp />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="size-10 sm:size-8"
                                title="Descendre"
                                disabled={idx === agents.length - 1}
                                onClick={() => moveAgent(a.id, "down")}
                              >
                                <ArrowDown />
                              </Button>
                            </>
                          )}
                          <Button
                            variant="outline"
                            size="icon"
                            className="size-10 sm:size-8"
                            title="Modifier"
                            aria-label={`Modifier ${a.name}`}
                            onClick={() => startEdit(a.id, a)}
                          >
                            <Pencil />
                          </Button>
                          <Button
                            variant="outline"
                            size="icon"
                            className="size-10 sm:size-8 border-destructive/40 text-destructive hover:bg-destructive hover:text-destructive-foreground"
                            title="Arrivée / Départ / Suppression"
                            aria-label={`Supprimer ${a.name}`}
                            onClick={() => openDialog(a)}
                          >
                            <Trash2 />
                          </Button>
                        </div>
                      </td>
                    </>
                  )}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Arrival / departure / delete dialog */}
      <Dialog open={!!dialogAgent} onOpenChange={(o) => !o && closeDialog()}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{dialogAgent?.name}</DialogTitle>
            <DialogDescription>
              L'arrivée masque l'agent avant le mois choisi ; le départ le masque
              à partir du mois choisi (et les années suivantes). Les mois hors de
              cette période restent vides et l'historique est conservé. La
              suppression définitive efface tout son planning.
            </DialogDescription>
          </DialogHeader>

          {!confirmDelete ? (
            <div className="space-y-4">
              {/* Arrival */}
              <div className="rounded-lg border border-border p-3">
                <label className="mb-2 flex items-center gap-2 text-sm font-semibold">
                  <Checkbox
                    checked={dArrEnabled}
                    onCheckedChange={(v) => setDArrEnabled(v === true)}
                  />
                  <LogIn className="size-4" /> Arrivée à partir de
                </label>
                {dArrEnabled ? (
                  <div className="flex flex-wrap items-end gap-2">
                    <Select
                      value={String(dArrMonth)}
                      onValueChange={(v) => setDArrMonth(Number(v))}
                    >
                      <SelectTrigger className="w-36">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {MONTHS.map((m, i) => (
                          <SelectItem key={m} value={String(i)}>
                            {m}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Select
                      value={String(dArrYear)}
                      onValueChange={(v) => setDArrYear(Number(v))}
                    >
                      <SelectTrigger className="w-28">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {years.map((y) => (
                          <SelectItem key={y} value={String(y)}>
                            {y}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                ) : (
                  <span className="text-sm text-muted-foreground">
                    Présent tout de suite (aucune date d'arrivée).
                  </span>
                )}
              </div>

              {/* Departure */}
              <div className="rounded-lg border border-border p-3">
                <label className="mb-2 flex items-center gap-2 text-sm font-semibold">
                  <Checkbox
                    checked={depEnabled}
                    onCheckedChange={(v) => setDepEnabled(v === true)}
                  />
                  <LogOut className="size-4" /> Départ à partir de
                </label>
                {depEnabled ? (
                  <div className="flex flex-wrap items-end gap-2">
                    <Select
                      value={String(depMonth)}
                      onValueChange={(v) => setDepMonth(Number(v))}
                    >
                      <SelectTrigger className="w-36">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {MONTHS.map((m, i) => (
                          <SelectItem key={m} value={String(i)}>
                            {m}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Select
                      value={String(depYear)}
                      onValueChange={(v) => setDepYear(Number(v))}
                    >
                      <SelectTrigger className="w-28">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {years.map((y) => (
                          <SelectItem key={y} value={String(y)}>
                            {y}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                ) : (
                  <span className="text-sm text-muted-foreground">
                    Présent ensuite (aucune date de départ).
                  </span>
                )}
              </div>

              <div className="flex items-center justify-between rounded-lg border border-destructive/30 p-3">
                <span className="text-sm text-muted-foreground">
                  Retirer l'agent et tout son historique
                </span>
                <Button
                  variant="outline"
                  className="text-destructive hover:bg-destructive hover:text-destructive-foreground"
                  onClick={() => setConfirmDelete(true)}
                >
                  <Trash2 className="size-4" /> Suppression définitive
                </Button>
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              <p className="text-sm">
                Cette action supprime définitivement{" "}
                <strong>{dialogAgent?.name}</strong> et tout son planning sur
                toutes les années. Elle est irréversible.
              </p>
            </div>
          )}

          <DialogFooter>
            {confirmDelete ? (
              <>
                <Button variant="outline" onClick={() => setConfirmDelete(false)}>
                  Retour
                </Button>
                <Button
                  className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                  onClick={deletePermanently}
                >
                  <Trash2 className="size-4" /> Confirmer la suppression
                </Button>
              </>
            ) : (
              <>
                <Button variant="outline" onClick={closeDialog}>
                  Annuler
                </Button>
                <Button onClick={saveDialog}>
                  <Save className="size-4" /> Enregistrer
                </Button>
              </>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
