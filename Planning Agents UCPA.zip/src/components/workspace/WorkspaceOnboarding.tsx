import { useState } from "react";
import { Clock, Loader2, LogIn, LogOut, Plus, Users, X } from "lucide-react";
import { toast } from "sonner";

import { useWorkspace, DEFAULT_TITLES } from "@/lib/workspace/workspace-context";
import { useAuth } from "@/lib/auth/auth-context";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export function WorkspaceOnboarding() {
  const { createWorkspace, joinWorkspace, pendingMemberships, cancelPending } = useWorkspace();
  const { user, signOut } = useAuth();
  const [name, setName] = useState("");
  const [mainTitle, setMainTitle] = useState<string>(DEFAULT_TITLES.main_title);
  const [subtitle, setSubtitle] = useState<string>(DEFAULT_TITLES.subtitle);
  const [printTitle, setPrintTitle] = useState<string>(DEFAULT_TITLES.print_title);
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState<"create" | "join" | null>(null);

  const onCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy("create");
    try {
      await createWorkspace(name, {
        main_title: mainTitle,
        subtitle,
        print_title: printTitle,
      });
      toast.success("Équipe créée");
    } catch (err) {
      toast.error("Impossible de créer l'équipe", {
        description: err instanceof Error ? err.message : undefined,
      });
    } finally {
      setBusy(null);
    }
  };

  const onJoin = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy("join");
    try {
      await joinWorkspace(code.trim());
      setCode("");
      toast.success("Demande envoyée", {
        description: "Le propriétaire doit valider votre accès avant que vous puissiez voir le planning.",
      });
    } catch (err) {
      toast.error("Code invalide", {
        description: err instanceof Error ? err.message : undefined,
      });
    } finally {
      setBusy(null);
    }
  };

  return (
    <div className="mx-auto flex min-h-screen max-w-lg flex-col justify-center gap-5 px-4 py-10">
      <div className="text-center">
        <div className="mx-auto flex size-12 items-center justify-center rounded-xl bg-primary text-primary-foreground">
          <Users className="size-6" />
        </div>
        <h1 className="mt-3 text-2xl font-bold">Bienvenue{user?.email ? `, ${user.email}` : ""}</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Créez une équipe ou rejoignez-en une avec un code d'invitation.
        </p>
      </div>

      {pendingMemberships.length > 0 && (
        <div className="rounded-2xl border border-amber-300 bg-amber-50 p-5 shadow-sm dark:border-amber-500/40 dark:bg-amber-500/10">
          <h2 className="flex items-center gap-2 text-base font-semibold text-amber-900 dark:text-amber-200">
            <Clock className="size-4" /> Demandes en attente
          </h2>
          <p className="mt-1 text-sm text-amber-800/80 dark:text-amber-200/80">
            Le propriétaire doit approuver votre accès. Vous verrez le planning dès validation.
          </p>
          <ul className="mt-3 space-y-2">
            {pendingMemberships.map((m) => (
              <li
                key={m.id}
                className="flex items-center justify-between gap-2 rounded-xl bg-background/80 px-3 py-2"
              >
                <span className="truncate font-medium">{m.name}</span>
                <Button
                  size="sm"
                  variant="ghost"
                  className="text-destructive hover:text-destructive"
                  onClick={() => void cancelPending(m.id)}
                >
                  <X className="mr-1 size-4" /> Annuler
                </Button>
              </li>
            ))}
          </ul>
        </div>
      )}

      <form onSubmit={onCreate} className="rounded-2xl border border-border bg-card p-5 shadow-sm">
        <h2 className="flex items-center gap-2 text-base font-semibold">
          <Plus className="size-4 text-primary" /> Créer une équipe
        </h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Vous en devenez le propriétaire et obtenez un code à partager.
        </p>
        <div className="mt-3 space-y-2">
          <Label htmlFor="ws-name">Nom de l'équipe</Label>
          <Input
            id="ws-name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Mon équipe"
          />
        </div>
        <div className="mt-3 space-y-2">
          <Label htmlFor="ws-main">Titre principal</Label>
          <Input
            id="ws-main"
            value={mainTitle}
            onChange={(e) => setMainTitle(e.target.value)}
            placeholder="Planning des agents"
          />
        </div>
        <div className="mt-3 space-y-2">
          <Label htmlFor="ws-sub">Sous-titre</Label>
          <Input
            id="ws-sub"
            value={subtitle}
            onChange={(e) => setSubtitle(e.target.value)}
            placeholder="Gestion du planning annuel"
          />
        </div>
        <div className="mt-3 space-y-2">
          <Label htmlFor="ws-print">Titre d'impression</Label>
          <Input
            id="ws-print"
            value={printTitle}
            onChange={(e) => setPrintTitle(e.target.value)}
            placeholder="PLANNING DES AGENTS"
          />
        </div>
        <Button type="submit" className="mt-4 w-full" disabled={busy !== null}>
          {busy === "create" && <Loader2 className="mr-2 size-4 animate-spin" />}
          Créer l'équipe
        </Button>
      </form>

      <form onSubmit={onJoin} className="rounded-2xl border border-border bg-card p-5 shadow-sm">
        <h2 className="flex items-center gap-2 text-base font-semibold">
          <LogIn className="size-4 text-primary" /> Rejoindre un workspace
        </h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Entrez un code à 6 chiffres. Le propriétaire devra approuver votre demande.
        </p>
        <div className="mt-3 flex gap-2">
          <Input
            value={code}
            onChange={(e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
            placeholder="000000"
            inputMode="numeric"
            className="text-center text-lg font-bold tracking-[0.4em]"
          />
          <Button type="submit" disabled={busy !== null || code.length !== 6}>
            {busy === "join" && <Loader2 className="mr-2 size-4 animate-spin" />}
            Demander l'accès
          </Button>
        </div>
      </form>

      <div className="text-center">
        <Button variant="ghost" size="sm" onClick={() => void signOut()}>
          <LogOut className="mr-1.5 size-4" /> Se déconnecter
        </Button>
      </div>
    </div>
  );
}
