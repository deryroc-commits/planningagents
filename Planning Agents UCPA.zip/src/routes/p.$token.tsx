import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import {
  CalendarDays,
  ChevronLeft,
  ChevronRight,
  Loader2,
  Clock,
} from "lucide-react";

import { supabase } from "@/integrations/supabase/client";
import {
  MONTHS,
  codesMap,
  dateOfDayIndex,
  dayIndicesForMonth,
  dayLetter,
  fmtHours,
  holidaysForYear,
  isWeekend,
} from "@/lib/planning/calc";
import { DEFAULT_COLORS } from "@/lib/planning/defaults";
import {
  resolveCodeColor,
  type Agent,
  type ColorScheme,
  type PlanningCode,
  type YearPlanning,
} from "@/lib/planning/types";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface SharedPlanning {
  ok: boolean;
  reason?: string;
  mode?: "perso" | "general";
  workspaceName?: string;
  year?: number;
  expiresAt?: string | null;
  codes?: PlanningCode[];
  colors?: ColorScheme | null;
  agents?: Agent[];
  planning?: YearPlanning;
}

function fmtExpiry(expiresAt: string | null | undefined): {
  text: string;
  remainingText: string;
  expired: boolean;
} {
  if (!expiresAt) {
    return {
      text: "Sans expiration",
      remainingText: "Valide indéfiniment",
      expired: false,
    };
  }
  const d = new Date(expiresAt);
  const expired = d.getTime() < Date.now();
  const remainingDays = Math.max(
    0,
    Math.ceil((d.getTime() - Date.now()) / 86_400_000),
  );
  return {
    text: expired
      ? `Expiré le ${d.toLocaleDateString("fr-FR")}`
      : `Expire le ${d.toLocaleDateString("fr-FR")}`,
    remainingText: expired
      ? "Lien expiré"
      : remainingDays === 0
        ? "Expire aujourd'hui"
        : `${remainingDays} jour${remainingDays > 1 ? "s" : ""} restant${remainingDays > 1 ? "s" : ""}`,
    expired,
  };
}

type Search = { y: number; mo: number; ms: number[]; msInvalid: boolean };

export const Route = createFileRoute("/p/$token")({
  ssr: false,
  validateSearch: (search: Record<string, unknown>): Search => {
    const now = new Date();
    const y = Number(search.y);
    const mo = Number(search.mo);
    // `ms` can arrive as a comma string ("6,7") on the first hit, or as a real
    // array ([6,7]) / number (7) after the router re-stringifies the search.
    const rawMs = search.ms;
    // Client-side validation: `ms`, when present, must be a string, a number,
    // or an array. Anything else (object, boolean…) means a malformed link.
    const msProvided = rawMs != null;
    const msTypeValid =
      !msProvided ||
      typeof rawMs === "string" ||
      typeof rawMs === "number" ||
      Array.isArray(rawMs);
    const rawMsList: unknown[] = Array.isArray(rawMs)
      ? rawMs
      : typeof rawMs === "string"
        ? rawMs.split(",")
        : rawMs == null
          ? []
          : [rawMs];
    const ms = rawMsList
      .map((v) => Number(v))
      .filter((v) => Number.isInteger(v) && v >= 0 && v <= 11);
    const uniqueMs = Array.from(new Set(ms)).sort((a, b) => a - b);
    // A provided `ms` that resolves to no valid month (wrong type or garbage
    // values) is treated as an invalid link rather than silently defaulting.
    const msInvalid = msProvided && (!msTypeValid || uniqueMs.length === 0);
    return {
      y: Number.isFinite(y) && y >= 2000 && y <= 2100 ? y : now.getFullYear(),
      mo: Number.isFinite(mo) && mo >= 0 && mo <= 11 ? mo : now.getMonth(),
      ms: uniqueMs.length
        ? uniqueMs
        : Array.from({ length: 12 }, (_, i) => i),
      msInvalid,
    };
  },
  head: () => ({
    meta: [
      { title: "Mon planning" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: SharedPlanningPage,
});

function SharedPlanningPage() {
  const { token } = Route.useParams();
  const { y, mo, ms, msInvalid } = Route.useSearch();
  const [year] = useState(y);
  const allowedMonths = ms;
  const [month, setMonth] = useState(
    allowedMonths.includes(mo) ? mo : allowedMonths[0],
  );
  const goPrev = () => {
    const idx = allowedMonths.indexOf(month);
    setMonth(allowedMonths[(idx - 1 + allowedMonths.length) % allowedMonths.length]);
  };
  const goNext = () => {
    const idx = allowedMonths.indexOf(month);
    setMonth(allowedMonths[(idx + 1) % allowedMonths.length]);
  };
  const [data, setData] = useState<SharedPlanning | null>(null);
  const [loading, setLoading] = useState(true);


  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    (async () => {
      const { data: res, error } = await supabase.rpc("get_shared_planning", {
        _token: token,
        _year: year,
      });
      if (cancelled) return;
      if (error) {
        setData({ ok: false, reason: "error" });
      } else {
        setData(res as unknown as SharedPlanning);
      }
      setLoading(false);
    })();
    return () => {
      cancelled = true;
    };
  }, [token, year]);

  if (msInvalid) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background px-4">
        <div className="max-w-sm text-center">
          <h1 className="text-xl font-semibold">Lien invalide</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Ce lien de planning est incorrect ou incomplet (les mois demandés ne
            sont pas valides). Demandez un nouveau QR code à votre responsable.
          </p>
          <Button asChild variant="outline" className="mt-6">
            <Link to="/">Retour à l'accueil</Link>
          </Button>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <Loader2 className="size-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!data || !data.ok) {
    const expired = data?.reason === "expired";
    return (
      <div className="flex min-h-screen items-center justify-center bg-background px-4">
        <div className="max-w-sm text-center">
          <h1 className="text-xl font-semibold">
            {expired ? "Lien expiré" : "Lien indisponible"}
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">
            {expired
              ? "Ce QR code a expiré. Demandez un nouveau QR code à votre responsable."
              : "Ce lien de planning n'existe plus ou a été régénéré. Demandez un nouveau QR code à votre responsable."}
          </p>
          <Button asChild variant="outline" className="mt-6">
            <Link to="/">Retour à l'accueil</Link>
          </Button>
        </div>
      </div>
    );
  }

  const colors = { ...DEFAULT_COLORS, ...(data.colors ?? {}) } as ColorScheme;
  const codes = data.codes ?? [];
  const agents = data.agents ?? [];
  const planning = data.planning ?? {};

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-30 border-b border-border bg-card/95 backdrop-blur">
        <div className="mx-auto flex max-w-4xl items-center gap-2 px-4 py-3">
          <div className="flex size-9 items-center justify-center rounded-lg bg-primary text-primary-foreground">
            <CalendarDays className="size-5" />
          </div>
          <div className="min-w-0">
            <h1 className="truncate text-sm font-bold leading-tight">
              {data.mode === "perso" && agents[0]
                ? agents[0].name
                : "Planning de l'équipe"}
            </h1>
            <p className="truncate text-xs text-muted-foreground">
              {data.workspaceName}
              {data.mode === "general" ? " — planning général" : ""}
            </p>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-4xl px-4 py-4">
        {(() => {
          const expiry = fmtExpiry(data.expiresAt ?? null);
          return (
            <div
              className={`mb-4 flex items-center gap-2 rounded-lg border px-3 py-2 ${
                expiry.expired
                  ? "border-destructive/30 bg-destructive/10"
                  : "border-border bg-muted/40"
              }`}
            >
              <Clock
                className={`size-4 shrink-0 ${expiry.expired ? "text-destructive" : "text-muted-foreground"}`}
              />
              <div>
                <p
                  className={`text-xs font-semibold ${
                    expiry.expired ? "text-destructive" : "text-foreground"
                  }`}
                >
                  {expiry.text}
                </p>
                <p className="text-[11px] text-muted-foreground">
                  {expiry.remainingText}
                </p>
              </div>
            </div>
          );
        })()}
        <div className="mb-4 flex items-center justify-center gap-1">
          <Button
            variant="outline"
            size="icon"
            onClick={goPrev}
            disabled={allowedMonths.length <= 1}
            aria-label="Mois précédent"
          >
            <ChevronLeft />
          </Button>
          <Select value={String(month)} onValueChange={(v) => setMonth(Number(v))}>
            <SelectTrigger className="w-52">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {allowedMonths.map((i: number) => (
                <SelectItem key={i} value={String(i)}>
                  {MONTHS[i]} {year}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button
            variant="outline"
            size="icon"
            onClick={goNext}
            disabled={allowedMonths.length <= 1}
            aria-label="Mois suivant"
          >
            <ChevronRight />
          </Button>
        </div>

        <div className="mb-4 rounded-lg border border-border bg-muted/40 px-3 py-2">
          <p className="mb-1.5 text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
            {allowedMonths.length === 12
              ? `Planning disponible pour toute l'année ${year}`
              : `Mois disponibles (${allowedMonths.length}) — ${year}`}
          </p>
          <div className="flex flex-wrap gap-1.5">
            {allowedMonths.map((i: number) => {
              const on = i === month;
              return (
                <button
                  key={i}
                  type="button"
                  onClick={() => setMonth(i)}
                  className={
                    on
                      ? "rounded-md bg-primary px-2 py-0.5 text-xs font-semibold text-primary-foreground"
                      : "rounded-md border border-border px-2 py-0.5 text-xs text-muted-foreground hover:bg-accent"
                  }
                >
                  {MONTHS[i]}
                </button>
              );
            })}
          </div>
        </div>




        {data.mode === "perso" ? (
          <PersonalMonth
            agent={agents[0]}
            planning={planning}
            codes={codes}
            colors={colors}
            year={year}
            month={month}
          />
        ) : (
          <GeneralMonth
            agents={agents}
            planning={planning}
            codes={codes}
            colors={colors}
            year={year}
            month={month}
          />
        )}
      </main>
    </div>
  );
}

function PersonalMonth({
  agent,
  planning,
  codes,
  colors,
  year,
  month,
}: {
  agent?: Agent;
  planning: YearPlanning;
  codes: PlanningCode[];
  colors: ColorScheme;
  year: number;
  month: number;
}) {
  const map = useMemo(() => codesMap(codes), [codes]);
  const holidays = useMemo(() => holidaysForYear(year), [year]);
  const indices = useMemo(() => dayIndicesForMonth(year, month), [year, month]);
  const row = agent ? (planning[agent.id] ?? {}) : {};

  if (!agent) {
    return (
      <p className="text-center text-sm text-muted-foreground">
        Agent introuvable.
      </p>
    );
  }

  const total = indices.reduce((sum, i) => {
    const c = map[row[i] ?? ""];
    return sum + (c ? c.hours : 0);
  }, 0);

  return (
    <div className="space-y-2">
      <div className="overflow-hidden rounded-lg border border-border bg-card">
        {indices.map((i) => {
          const date = dateOfDayIndex(year, i);
          const value = row[i];
          const code = value ? map[value] : undefined;
          const holiday = holidays[i];
          const weekend = isWeekend(date);
          const style = code
            ? (() => {
                const c = resolveCodeColor(code, colors);
                return { backgroundColor: c.bg, color: c.fg };
              })()
            : holiday
              ? { backgroundColor: colors.holiday.bg, color: colors.holiday.fg }
              : weekend
                ? { backgroundColor: colors.weekend.bg }
                : undefined;
          return (
            <div
              key={i}
              className="flex items-center gap-3 border-b border-border px-3 py-2 text-sm last:border-0"
              style={style}
            >
              <div className="w-10 shrink-0 text-center">
                <div className="text-base font-bold leading-none">
                  {date.getDate()}
                </div>
                <div className="text-[10px] uppercase opacity-70">
                  {dayLetter(date)}
                </div>
              </div>
              <div className="min-w-0 flex-1">
                {code ? (
                  <>
                    <span className="font-semibold">{code.code}</span>
                    <span className="ml-2 opacity-80">{code.label}</span>
                  </>
                ) : holiday ? (
                  <span className="italic opacity-80">{holiday}</span>
                ) : (
                  <span className="opacity-40">—</span>
                )}
              </div>
              {code && code.hours > 0 && (
                <div className="shrink-0 text-xs font-medium opacity-80">
                  {fmtHours(code.hours)} h
                </div>
              )}
            </div>
          );
        })}
      </div>
      <div className="flex justify-between rounded-lg border border-border bg-muted px-3 py-2 text-sm font-semibold">
        <span>Total du mois</span>
        <span>{fmtHours(total)} h</span>
      </div>
    </div>
  );
}

function GeneralMonth({
  agents,
  planning,
  codes,
  colors,
  year,
  month,
}: {
  agents: Agent[];
  planning: YearPlanning;
  codes: PlanningCode[];
  colors: ColorScheme;
  year: number;
  month: number;
}) {
  const map = useMemo(() => codesMap(codes), [codes]);
  const holidays = useMemo(() => holidaysForYear(year), [year]);
  const indices = useMemo(() => dayIndicesForMonth(year, month), [year, month]);

  return (
    <div className="overflow-x-auto rounded-lg border border-border bg-card">
      <table className="w-full border-collapse text-xs">
        <thead>
          <tr>
            <th className="sticky left-0 z-10 border-b border-r border-border bg-muted px-2 py-1.5 text-left font-semibold">
              Agent
            </th>
            {indices.map((i) => {
              const date = dateOfDayIndex(year, i);
              const weekend = isWeekend(date);
              const holiday = holidays[i];
              return (
                <th
                  key={i}
                  className="border-b border-border px-1 py-1 text-center font-medium"
                  style={
                    holiday
                      ? { backgroundColor: colors.holiday.bg, color: colors.holiday.fg }
                      : weekend
                        ? { backgroundColor: colors.weekend.bg }
                        : undefined
                  }
                >
                  <div className="font-bold leading-none">{date.getDate()}</div>
                  <div className="text-[9px] uppercase opacity-70">
                    {dayLetter(date)}
                  </div>
                </th>
              );
            })}
          </tr>
        </thead>
        <tbody>
          {agents.map((a) => {
            const row = planning[a.id] ?? {};
            return (
              <tr key={a.id}>
                <td className="sticky left-0 z-10 whitespace-nowrap border-b border-r border-border bg-card px-2 py-1 font-medium">
                  {a.name}
                </td>
                {indices.map((i) => {
                  const date = dateOfDayIndex(year, i);
                  const value = row[i];
                  const code = value ? map[value] : undefined;
                  const holiday = holidays[i];
                  const weekend = isWeekend(date);
                  const style = code
                    ? (() => {
                        const c = resolveCodeColor(code, colors);
                        return { backgroundColor: c.bg, color: c.fg };
                      })()
                    : holiday
                      ? { backgroundColor: colors.holiday.bg }
                      : weekend
                        ? { backgroundColor: colors.weekend.bg }
                        : undefined;
                  return (
                    <td
                      key={i}
                      className="border-b border-border px-1 py-1 text-center"
                      style={style}
                    >
                      {value ?? ""}
                    </td>
                  );
                })}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
